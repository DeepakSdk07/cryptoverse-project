export const portfolioDetails = [
  { name: "Tether", amount: 375, id: 0 },
  { name: "Luna", amount: 375, id: 1 },
  { name: "Ethereum", amount: 250, id: 2 },
];
